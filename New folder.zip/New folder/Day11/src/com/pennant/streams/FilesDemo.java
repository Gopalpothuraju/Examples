package com.pennant.streams;


import java.io.File;
import java.io.IOException;

public class FilesDemo {

	public static void main(String[] args) throws IOException {
	File fileOne=new File("./Abcde");

	fileOne.mkdir();
	
	if(fileOne.exists()){
		if(fileOne.isFile()){
		System.out.println(fileOne.canExecute());
		System.out.println(fileOne.canRead());
		System.out.println(fileOne.canWrite());
		System.out.println(fileOne.canExecute());
		//System.out.println(fileOne.delete());
		System.out.println(fileOne.getAbsoluteFile());
		System.out.println(fileOne.getAbsolutePath());
		System.out.println(fileOne.getCanonicalPath());
		System.out.println(fileOne.getFreeSpace());
		System.out.println(fileOne.getName());
		System.out.println(fileOne.getParent());
		System.out.println(fileOne.getPath());
		System.out.println(fileOne.getTotalSpace());
		System.out.println(fileOne.getUsableSpace());
		System.out.println(fileOne.hashCode());
		System.out.println(fileOne.isAbsolute());
		System.out.println(fileOne.isDirectory());
		System.out.println(fileOne.isHidden());
		System.out.println(fileOne.lastModified());
		System.out.println(fileOne.length());
		System.out.println(fileOne.mkdir());
		//System.out.println(fileOne.renameTo(fileTwo));
		
		}else if(fileOne.isDirectory()){
			File files1=new File("./Abcde/zse.txt");
			files1.createNewFile();
			File files2=new File("./Abcde/zse1.txt");
			files2.createNewFile();
			File files3=new File("./Abcde/zse2.txt");
			files3.createNewFile();
			
			String[] files=fileOne.list();
			for (int i = 0; i < files.length; i++) {
				System.out.println(files[i]);
			}
		}
	}
	}

}
