package com.constructors;

import java.util.Scanner;

public class Subscriber {
	int id;
	String name;
	String plan; 
	double planCost;
	int duration;
	int noOfFreeMinutes;
	int noOfFreeSms;
	int freeData;
	int extraMinutes;
	int extraSms;
	int extraData;
	double costOfExtraMinute;
	double costOfExtraSms;
	double costOfExtraData;
	int noOfRoamingCalls;
	double costPerRoamingCalls;
	long mobileNumber;
	static String network = "Idea";
	String location;

	public Subscriber(int id, String name, String plan, double planCost, int duration, int noOfFreeMinutes,
			int noOfFreeSms, int freeData, int extraMinutes, int extraSms, int extraData, double costOfExtraMinute,
			double costOfExtraSms, double costOfExtraData, int noOfRoamingCalls, double costPerRoamingCalls,
			long mobileNumber, String location) {
		super();
		this.id = id;
		this.name = name;
		this.plan = plan;
		this.planCost = planCost;
		this.duration = duration;
		this.noOfFreeMinutes = noOfFreeMinutes;
		this.noOfFreeSms = noOfFreeSms;
		this.freeData = freeData;
		this.extraMinutes = extraMinutes;
		this.extraSms = extraSms;
		this.extraData = extraData;
		this.costOfExtraMinute = costOfExtraMinute;
		this.costOfExtraSms = costOfExtraSms;
		this.costOfExtraData = costOfExtraData;
		this.noOfRoamingCalls = noOfRoamingCalls;
		this.costPerRoamingCalls = costPerRoamingCalls;
		this.mobileNumber = mobileNumber;
		this.location = location;
	}

	public Subscriber(int id, String name, String plan, int duration, long mobileNumber, String location) {
		super();
		this.id = id;
		this.name = name;
		this.plan = plan;
		this.duration = duration;
		this.mobileNumber = mobileNumber;
		this.location = location;
	}

	public void getDetails() {
		System.out.println("===========CUSTOMER DETAILS=============");
		System.out.println("ID : " + id);
		System.out.println("Name : " + name);
		System.out.println("Plan your selected is : " + plan);
		System.out.println("duration :" + duration+" days");
		System.out.println("Your plan having " + noOfFreeMinutes + "free minutes and " + noOfFreeSms + "free SMS "
				+ freeData + "free Data");
		System.out.println("You Used Calls" + (extraMinutes + noOfFreeMinutes) + "Sms" + (extraSms + noOfFreeSms)
				+ "Data " + (freeData + extraData));
		System.out.println("You used roaming calls " + noOfRoamingCalls);
		System.out.println("Your mobile number : " + mobileNumber);
		System.out.println("Your location : " + location);
	}

	public void getDetailsToHR() {
		System.out.println("===========CUSTOMER DETAILS=============");
		System.out.println("ID : " + id);
		System.out.println("Name : " + name);
		System.out.println("Plan Customer selected is : " + plan);
		System.out.println("duration :" + duration+" days");
		System.out.println(" mobile number : " + mobileNumber);
		System.out.println(" location : " + location);
	}

	public double generateBill() {
		double bill;
		double gstTax = 25.98;
		double discount = 10 % 100;
		bill = planCost + (costOfExtraMinute * extraMinutes) + (costOfExtraSms * extraSms)
				+ (costOfExtraData * extraData) + (noOfRoamingCalls * costPerRoamingCalls) + gstTax - discount;
		return bill;
	}

	public double turnOverPerMonth(double bill[]) {
		double turnOver = 0;
		for (int i = 0; i < bill.length; i++) {
			turnOver = turnOver + bill[i];
		}

		return turnOver;
	}

	public static void main(String[] args) {

		Subscriber[] subscribers = new Subscriber[3];
		subscribers[0] = new Subscriber(101, "Gopal", "OneMonthPlan", 250.00, 28, 12878, 10000, 50000, 21078, 500, 3400,
				1.25, 0.50, 2.15, 3450, 1.0, 9908922714l, "Antarvedi");
		subscribers[1] = new Subscriber(102, "mani", "ThreeMonthPlan", 550.00, 84, 32878, 30000, 150000, 41078, 700,
				5400, 1.5, 0.30, 1.15, 1450, 0.5, 9908922714l, "Antarvedi");
		subscribers[2] = new Subscriber(103, "bhaskar", "OneMonthPlan", 250.00, 28, 12878, 10000, 50000, 21078, 300,
				1400, 1.25, 0.50, 2.15, 450, 1.0, 9908922714l, "Antarvedi");

		System.out.println("1.Customer \n  2.HR \n 3.Management \n 4.exit");
		System.out.println("Select your Option: ");
		Scanner scanner = new Scanner(System.in);
		int option = scanner.nextInt();
		switch (option) {
		case 1:
			System.out.println("Enter your Id: ");
			int id = scanner.nextInt();
			for (int i = 0; i < subscribers.length; i++) {
				if (id == subscribers[i].id) {
					subscribers[i].getDetails();
					System.out.println(subscribers[i].generateBill());
				}
			}
			break;
		case 2:
			for (int i = 0; i < subscribers.length; i++) {
				Subscriber hr = new Subscriber(subscribers[i].id, subscribers[i].name, subscribers[i].plan,
						subscribers[i].duration, subscribers[i].mobileNumber, subscribers[i].location);
				hr.getDetailsToHR();
			}
			break;
		case 3:
			double[] totalBill = new double[subscribers.length];
			Subscriber management = null;
			for (int i = 0; i < subscribers.length; i++) {
				management = new Subscriber(subscribers[i].id, subscribers[i].name, subscribers[i].plan,
						subscribers[i].planCost, subscribers[i].duration, subscribers[i].noOfFreeMinutes,
						subscribers[i].noOfFreeSms, subscribers[i].freeData, subscribers[i].extraMinutes,
						subscribers[i].extraSms, subscribers[i].extraData, subscribers[i].costOfExtraMinute,
						subscribers[i].costOfExtraSms, subscribers[i].costOfExtraData, subscribers[i].noOfRoamingCalls,
						subscribers[i].costPerRoamingCalls, subscribers[i].mobileNumber, subscribers[i].location);

				totalBill[i] = management.generateBill();

			}
			double turnOver = management.turnOverPerMonth(totalBill);
			System.out.println("Total turn over for this month is : " + turnOver);
			break;
		case 4:
			System.exit(0);
			break;
		default:
			System.err.println("please select appropiate option");
			break;
		}scanner.close();
	}

}
