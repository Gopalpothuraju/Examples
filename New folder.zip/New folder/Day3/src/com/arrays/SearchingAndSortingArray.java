package com.arrays;

import java.util.Scanner;

public class SearchingAndSortingArray {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int count = 0;
		int temp;
		int[] array = { 10, 56, 34, 78, 23, 89 };
		System.out.println("Enter a number which you want to search : ");
		int number = sc.nextInt();
		for (int i = 0; i < array.length; i++) {
			if (number == array[i]) {

				count++;
			}

		}
		if (count > 0) {
			System.out.println("Number is availble in array " + number);
		} else {
			System.out.println("Number is not available in array " + number);
		}

		System.out.println("==========Accesending order=========");
		for (int i = 1; i <= array.length-1; i++) {

			for (int j = i; j > 0; j--) {

				if (array[j] < array[j - 1]) {
					temp = array[j];
					array[j] = array[j - 1];
					array[j - 1] = temp;
				}
			}

		}
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
		
		System.out.println("\n ==========Decesending order=========");
		for (int i = 1; i <= array.length-1; i++) {

			for (int j = i; j > 0; j--) {

				if (array[j] > array[j - 1]) {
					temp = array[j];
					array[j] = array[j - 1];
					array[j - 1] = temp;
				}
			}

		}
		for (int i = 0; i < array.length; i++) {
			System.out.print(array[i] + " ");
		}
		sc.close();
	}

}
