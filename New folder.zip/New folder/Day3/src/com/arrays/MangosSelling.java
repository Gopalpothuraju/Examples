package com.arrays;

public class MangosSelling {
	public static boolean mangoSelling(int totalCount) {
		if (totalCount % 3 == 0) {
			return true;
		} else {
			return false;
		}
	}

	public static int totalCount(int totalCount, int[] mangoBags) {
		for (int i = 0; i < mangoBags.length; i++) {
			totalCount = totalCount + mangoBags[i];
		}
		return totalCount;
	}

	public static int removeMangos(int totalCount, int[] mangoBags) {
		int count = 0;

		if (totalCount % 3 == 1) {
			for (int i = 0; i < mangoBags.length; i++) {
				if (mangoBags[i] == 1) {
					mangoBags[i] = 0;
					count++;
				}else{
					count=0;
				}
			}

		} else if (totalCount % 3 == 2) {

			for (int i = 0; i < mangoBags.length; i++) {
				if (mangoBags[i] == 2) {
					mangoBags[i] = 0;
					count+=2;
				}else{
					count=0;
				}
			}
			if (count == 0) {
				
				for (int i = 0; i < mangoBags.length; i++) {
					while(count<=2){
						if (mangoBags[i] == 1) {
							mangoBags[i] = 0;
							count++;
						}
						else{
							i++;
					}break;
					}
				}
			}

		}
		return count;
	}

	public static void main(String[] args) {

		int[] mangoBags = { 3, 5, 4, 8, 4, 78, 23 };
		int totalCount = 0;
		totalCount = totalCount(totalCount, mangoBags);
		boolean flag = false;
		while (!flag) {
			flag = mangoSelling(totalCount);
			if (flag) {
				System.out.println("Mangos selled sucessfully...");

			} else {
				int count = removeMangos(totalCount, mangoBags);
				if(count==0){
					System.out.println("Your bags does't have "+(totalCount%3)+" mangos in a single bag ...");
					break;
				}else{
				System.out.println("you removed " + count + "bag from array");
				}
				totalCount = totalCount - count;
				flag = false;
			}
		}

	}
}