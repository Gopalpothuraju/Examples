package com.methods;

import java.util.Scanner;

public class PrimeNumber {
	static Scanner sc=new Scanner(System.in);
	/*void primeNumber(){
		int number;
		int count=0;
		System.out.println("Enter number : ");
		number=sc.nextInt();
		for (int i = 1; i <= number; i++) {
			if (number%i==0) {
				count++;
			}
		}
		if (count==2) {
			System.out.println("prime");
		}
		else
			System.out.println(" not prime");
		}*/
	static void primeNumber(int number){
		
		int count=0;
		
		for (int i = 1; i <= number; i++) {
			if (number%i==0) {
				count++;
			}
		}
		if (count==2) {
			System.out.println("prime");
		}
		else
			System.out.println(" not prime");
		}

	
		public static void main(String[] args) {
			//PrimeNumber p=new PrimeNumber();
			
			//p.primeNumber();
			
			
		
		System.out.println("Enter number : ");
		int number=sc.nextInt();
		PrimeNumber.primeNumber(number);
		sc.close();
		}
}
