package com.conditionalstatements;

import java.util.Scanner;

public class CastingVote {
public static void main(String[] args) {
	int age;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter Age");
	age=sc.nextInt();
	if(age>18){
		System.out.println("your eligible for vote");
	}else{
		System.out.println("your not eligible for vote");
	}
	sc.close();
}
}
