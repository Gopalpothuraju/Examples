package com.conditionalstatements;

import java.util.Scanner;

public class Grading {

	public static void main(String[] args) {
		int mathMarks;
		int phyicsMarks;
		int chemistryMarks;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter maths marks(out of 100)");
		mathMarks=sc.nextInt();
		System.out.println("Enter physics marks(out of 100)");
		phyicsMarks=sc.nextInt();
		System.out.println("Enter chemistry marks(out of 100)");
		chemistryMarks=sc.nextInt();
		if((mathMarks+chemistryMarks+phyicsMarks)/3 >=90 ){
			System.out.println("Distinction");
		}else if(((mathMarks+chemistryMarks+phyicsMarks)/3 <=90) &&( (mathMarks+chemistryMarks+phyicsMarks)/3 >70)){
			System.out.println("Grade A");
		}else if(((mathMarks+chemistryMarks+phyicsMarks)/3 <=70 )&& ((mathMarks+chemistryMarks+phyicsMarks)/3 >60)){
			System.out.println("Grade B");
		}else if(((mathMarks+chemistryMarks+phyicsMarks)/3 <=60 )&&((mathMarks+chemistryMarks+phyicsMarks)/3 >=40 )){
			System.out.println("Grade C");
		}else if((mathMarks+chemistryMarks+phyicsMarks)/3 >100){
			System.out.println("Sorry there is mistake in entering marks please check");
		}
		else{
			System.out.println("fail");
		}

		sc.close();
	}

}
