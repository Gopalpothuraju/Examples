package com.conditionalstatements;

import java.util.Scanner;

public class GreatestOfThreeNumbers {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter first number");
		int largestNumber=sc.nextInt();
		System.out.println("Enter second number");
		int secondNumber=sc.nextInt();
		if(secondNumber>largestNumber){
			largestNumber=secondNumber;
		}
		System.out.println("Enter third number");
		secondNumber=sc.nextInt();
		if(secondNumber>largestNumber){
			largestNumber=secondNumber;
		}
		System.out.println("The largest number is "+largestNumber);
		sc.close();
	}

}
