package com.conditionalstatements;

import java.util.Scanner;

public class MovieRating {

	public static void main(String[] args) {
		float star;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number of stars give for movie(out of 10)");
		star=sc.nextFloat();
		if(star==10 && star>=8){
			System.out.println("Industry Hit");
		}else if(star<8 && star>=6.5){
			System.out.println("Movie Super Hit");
		}else if(star<6.5 && star>=5){
			System.out.println("Movie  Hit");
		}else if(star<5 && star>=3.5){
			System.out.println("Movie Average");
		}else if(star<3.5 && star>=0){
			System.out.println("Movie flop");
		}else {
			System.out.println("Your out of range please give in b/w 10 only");
		}
	sc.close();

	}

}
