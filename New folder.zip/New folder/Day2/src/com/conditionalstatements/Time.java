package com.conditionalstatements;

import java.util.Scanner;

public class Time {
public static void main(String[] args) {
	float time;
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter time in 24hrs format");
	time=sc.nextFloat();
	if(time>12.00){
		System.out.println("Now time :"+(time-12)+" PM");
	}
	else{
		System.out.println("Now Time : "+(time)+" AM");
	}
	sc.close();
}
}
