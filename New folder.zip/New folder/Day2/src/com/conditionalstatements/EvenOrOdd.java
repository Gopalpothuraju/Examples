package com.conditionalstatements;

import java.util.Scanner;

public class EvenOrOdd {

	public static void main(String[] args) {
		int number;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter  number : ");
		number=sc.nextInt();
		if(number%2==0){
			System.out.println("Number "+number+" is even");
		}else{
			System.out.println("Number "+number+" is odd");
		}
		sc.close();
	}

}
