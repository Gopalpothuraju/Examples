package com.conditionalstatements;

import java.util.Scanner;

public class StrongNumber {
public static void main(String[] args) {
	int number; //145
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter number :");
	number=sc.nextInt();
	int res;
	int sum=0;//120
	int fact;
	int fNumber=number;
	while(number!=0){
		res=number%10; //5//4
		fact=1;
		for(int i=1;i<=res;i++){
			
			fact=fact*i; //1//2-//6//24---120
			
		}
		sum=sum+fact;//120+24=144
		 number=number/10;//14
	
	}
	if(sum==fNumber){
		System.out.println("its strong number"+fNumber);
	}else{
		System.out.println("its not strong number"+fNumber);
	}
	sc.close();
}
}
