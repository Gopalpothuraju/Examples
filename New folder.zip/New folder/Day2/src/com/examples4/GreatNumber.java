package com.examples4;

import java.util.Scanner;

public class GreatNumber {

	public static void main(String[] args) {
		int numberOne;
		int numberTwo;
		Scanner sc=new Scanner(System.in);

		System.out.println("Enter number one : ");
		numberOne=sc.nextInt();
		System.out.println("Enter number two : ");
		numberTwo=sc.nextInt();
		if(numberOne==6 || numberTwo==6){
			System.out.println(true);
		}else if((numberOne+numberTwo)==6 || (numberOne-numberTwo)==6){
			System.out.println(true);
		}else{
			System.out.println(false);
		}
sc.close();
	}

}
