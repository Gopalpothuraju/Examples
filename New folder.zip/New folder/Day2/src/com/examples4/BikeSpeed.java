package com.examples4;

import java.util.Scanner;

public class BikeSpeed {

	public static void main(String[] args) {
		int value=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("its your birthday..(true/false)");
		boolean bday=sc.nextBoolean();
		System.out.println("Enter speed of your bike");
		int bikeSpeed=sc.nextInt();
		if(bday){
			if(bikeSpeed<=60+5){
				value=0;
			}else if(bikeSpeed>61+5 && bikeSpeed<=80+5){
				value=1;
			}else if(bikeSpeed>80+5){
				value=2;
			}
		}else{
			if(bikeSpeed<=60){
				value=0;
			}else if(bikeSpeed>61 && bikeSpeed<=80){
				value=1;
			}else if(bikeSpeed>80){
				value=2;
			}
		}
		if(value==0){
			System.out.println("No Ticket");
		}else if(value==1){
			System.out.println("Small Ticket");
		}else if(value==2){
			System.out.println("Big Ticket");
		}
sc.close();
	}

}
