package com.pennant.inheritance;

public class SubClass extends Super {
	int subVar;
	String name;
	public SubClass(int superOne, int subVar) {
		super(superOne);
		this.subVar=subVar;
	}
	public SubClass(int superOne, String name) {
		super(superOne);
		this.name = name;
	}
	
	public SubClass(String name) {
		super();
		this.name = name;
	}
/*	@Override
	public String getNames() {
		return "in sub class: "+name;
	}*/
}
