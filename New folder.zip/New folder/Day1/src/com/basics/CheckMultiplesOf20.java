package com.basics;

import java.util.Scanner;

public class CheckMultiplesOf20 {
	public static void main(String[] args) {
		int number;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number");
		number = sc.nextInt();
		if (number >= 0) {
			if (number % 20 == 1 || number % 20 == 2) {
				System.out.println(true);
			} else {
				System.out.println(false);
			}
		}else{
			System.out.println("entered negative number");
		}
		sc.close();
	}
}
