package com.basics;

public class SumOfDigitsUsingLoop {
public static void main(String[] args) {
	int number=12121;
	int result=0;
	int value=0;
	if(number>=999 && number <=9999 ){
		while(number!=0){
			result=result+(number%10);
			//System.out.println(result);
			number=number/10;
			
		}
		System.out.println(result);
		
	
		}
		if(number>=9999 && number<=99999){
			while(number!=0){
				
				result=number%10;//1//2
				int pow=result;//1//2 
				for(int i=result;i>1;i--){
					pow=pow*(result);
					
				}
				value=value+pow;
				
				
			number=number/10;
		
	}
			System.out.println(value);
}
}
}
