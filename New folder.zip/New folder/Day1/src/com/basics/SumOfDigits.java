package com.basics;

public class SumOfDigits {
	public static void main(String[] args) {
		
	
	int numberOne=2345;
	int resultOne=numberOne/1000; //2
	
	
	int remainderOne=numberOne%1000;//345
	
	int resultTwo=remainderOne/100;//3
	int remainderTwo=remainderOne%100;//45

	
	int resultThree=remainderTwo/10;//4
	int remainderThree=remainderTwo%10;//5
	
	
	int sumOfDigits=resultOne+resultTwo+resultThree+remainderThree;
	System.out.println(resultOne+" + "+resultTwo+" + "+resultThree+" + "+remainderThree+"="+sumOfDigits);
	}
	
	
	
}
