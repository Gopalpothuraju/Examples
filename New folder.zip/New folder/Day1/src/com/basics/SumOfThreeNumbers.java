package com.basics;

import java.util.Scanner;

public class SumOfThreeNumbers {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	
	int numberOne; //14
	int numberTwo;
	int numberThree;
	System.out.println("Enter number one");
	numberOne=sc.nextInt();
	System.out.println("Enter number Two");
	numberTwo=sc.nextInt();	
	System.out.println("Enter number Three");
	numberThree=sc.nextInt();
	
	int resultOne=numberOne%10; //2
	numberOne=numberOne/10; //1
	
	int resultTwo=numberTwo%10;//
	numberTwo=numberTwo/10;
	int resultThree=numberThree%10;
	numberThree=numberThree/10;
	if(resultOne>=5){
		numberOne=(numberOne+1)*10;
		
	}else{
		numberOne=numberOne*10;
		
	}
	if(resultTwo>=5){
		numberTwo=(numberTwo+1)*10;
	}else{
		numberTwo=numberTwo*10;
		
	}
	if(resultThree>=5){
		numberThree=(numberThree+1)*10;
	}else{
		numberThree=numberThree*10;
		
	}
	int finalValue=numberOne+numberTwo+numberThree;
	System.out.println("sum of three numbers is: "+finalValue);
	sc.close();
}
}
