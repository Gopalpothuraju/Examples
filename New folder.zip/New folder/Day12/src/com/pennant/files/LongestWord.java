package com.pennant.files;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class LongestWord {

	public static void main(String[] args) throws IOException {
		String stringOne;
		FileOutputStream fos = new FileOutputStream("./longestword.txt");
		DataOutputStream dos = new DataOutputStream(fos);
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter a string");
		stringOne = reader.readLine();

		dos.writeChars(stringOne);
		System.out.println("end");

		FileInputStream fis = new FileInputStream("./longestword.txt");
		DataInputStream dis = new DataInputStream(fis);
		@SuppressWarnings("deprecation")
		String stringTwo = dis.readLine();

		String[] strings = stringTwo.split("\\s");

		String stringThree = strings[0];
		for (int i = 0; i < strings.length; i++) {

			if (stringThree.length() <= strings[i].length()) {
				stringThree = strings[i];
			}
		}
		System.out.println("largest word in the file is :\n " + stringThree);

		dos.close();
		fos.close();
		dis.close();
		fis.close();
	}

}
