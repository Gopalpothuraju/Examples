package com.pennant.mapinterface;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class MapDemo {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		Map<Long, String> mapValues=new HashMap<Long, String>();
		mapValues.put(9908922714l, "Gopal");
		mapValues.put(9618530219l, "siri");
		mapValues.put(9959936894l, "Bharathi");
		mapValues.put(9492456998l, "Gopal");
		mapValues.put(9866394274l, "mani");
		mapValues.put(9908922714l, "Gopi");
		System.out.println(mapValues);
		
		Set<Long> keys=mapValues.keySet();
		System.out.println(keys);
		System.out.println("Enter your mobile number : ");
		long key=scanner.nextLong();
		System.out.println(mapValues.get(key));
			
		
scanner.close();		
	}

}
