package com.oops.classndobject;

public class MobileApplication {
	String name="SAMSUNG";
	String model="M20";
	String ram="4GB";
	String rom="64GB";
	int simSlots=2;
	double price=12990.00;
	String color="NAVY BLUE";
	
	String[] cameraPixels={"7.2 MP (F)","16.8 MP (B)"};
	String displaySize="6.2INCH";
	String batteryCapacity="5000mah";
	double offers;
	public void getDetails(){
		System.out.println("===========MOBILE DETAILS==========");
		System.out.println("Name : "+name);
		System.out.println("Model No : "+model);
		System.out.println("RAM : "+ram);
		System.out.println("ROM :"+rom);
		System.out.println("No of sims"+simSlots);
		System.out.println("Camera pixels :"+cameraPixels[0]+ "\n \t"+cameraPixels[1]);
		System.out.println("Display Size"+displaySize);
		System.out.println("Battery Capacity : "+batteryCapacity);
	}
	public void getNewFeatures(){
		String[] accessories={"Charger","Sim opener","User Manual"};
		offers=10/100;
		System.out.println(accessories+"Accessories having");
		
	}
	public static void main(String[] args) {
		MobileApplication mobileApplication = new MobileApplication();
		mobileApplication.getDetails();
		mobileApplication.getNewFeatures();
		
		
	}

}
