package com.arrays;

public class Example {

	public static void main(String[] args) {
		int i=2;
		System.out.println(i++);
		System.out.println(i);

	}

}
