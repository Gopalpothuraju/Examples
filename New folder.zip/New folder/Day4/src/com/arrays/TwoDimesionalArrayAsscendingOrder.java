package com.arrays;

public class TwoDimesionalArrayAsscendingOrder {

	public static void main(String[] args) {
		int[][] array = { { 23, 43, 56 }, { 78, 8, 123 }, { 132, 156, 178 } };
		boolean flag = ascendingOrder(array);
		if (flag) {
			System.out.println(true);
		} else {
			System.out.println(false);
		}

	}

	public static boolean ascendingOrder(int[][] array) {
		boolean flag = true;
		int temp = 0;
		for (int i = 0; i < array.length; i++) {
			for (int j = 0; j < array[i].length; j++) {

				if (array[i][j] > temp) {
					 temp=array[i][j];
					
				} else {
					flag = false;
					break;
				}
			}
			
		}

		return flag;

	}

}
