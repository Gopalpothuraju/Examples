package com.arrays;

public class PlacingOfFoursAndFives {

	public static void main(String[] args) {
		int[] array = { 1,2,4,6,5,4,2,5};
		boolean flag = false;
		if (array[array.length - 1] != 4) {
			flag = checkingNumberOfFoursAndFives(array);
			if (flag) {
				int[] sortedArray = positionOfFourAndFive(array);
				System.out.println("Final Array is : ");
				for (int i = 0; i < sortedArray.length; i++) {
					System.out.print(sortedArray[i] + " ");
				}

			} else {
				System.err.println("Number 4's and 5's are not equal or number 4 having side by side");
			}
		} else {
			System.err.println("Last position is 4");
		}
	}

	public static int[] positionOfFourAndFive(int[] array) {
		int temp = 0;
		for (int i = 0; i < array.length; i++) {
			if (array[i] == 4 && array[i + 1] != 5) {

				for (int j = 1; j < array.length; j++) {
					// i=1 & i=6
					if (array[j] == 5 && array[j - 1] != 4) {
						temp = array[j];
						array[j] = array[i + 1];
						array[i + 1] = temp;
						break;
					}
				}
			}

		}

		return array;
	}

	public static boolean checkingNumberOfFoursAndFives(int[] array) {
		int count4 = 0;
		int count5 = 0;
		boolean flag = false;
		for (int i = 0; i < array.length; i++) {
			if (array[i] == 4) {
				count4++;
			}
			if (array[i] == 5) {
				count5++;
			}
		}
		if (count4 == count5) {
			for (int i = 0; i < array.length - 1; i++) {
				if (array[i] == 4 && array[i + 1] != 4) {
					flag = true;
				}

			}

		} else {
			flag = false;
		}
		return flag;
	}

}
