package com.pennant.exceptions;

public class StringException extends Exception {

	private static final long serialVersionUID = 1L;
	public StringException() {
		System.err.println("String is empty please enter string value");
	}

}
