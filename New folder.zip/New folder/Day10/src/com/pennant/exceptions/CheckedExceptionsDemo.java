package com.pennant.exceptions;

public class CheckedExceptionsDemo {
public static void main(String[] args) throws InterruptedException {
	System.out.println("Execution Started");
	Thread.sleep(3000);
	System.out.println("Execution Done..");
}
}
