package com.pennant.narrowingndweidining;

public class NarrowingAndWeidiningDemo {
public static void main(String[] args) {
	
	System.out.println("==Narrowing==");
	int x=10;
	long y=x;
	System.out.println("integer"+x);
	System.out.println("converted to long "+y);
	System.out.println("==Weidining==");
	long z=245;
	int i=(int)z;
	System.out.println("long "+z);
	System.out.println("convert to int "+i);
	System.out.println("---------------------");
	
	int j=34;
	float k=j;
	System.out.println("int "+j);
	System.out.println("convert to float : "+k);
	
	float m=45.78f;
	int n=(int)m;
	System.out.println("float"+m);
	System.out.println("convert to int "+n);
}
}
