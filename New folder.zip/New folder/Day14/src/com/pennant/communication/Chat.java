package com.pennant.communication;

public class Chat {
	boolean flag=false;
public synchronized void getQuestion(String msg){
	if(flag){
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	System.out.println(Thread.currentThread().getName()+" "+msg);
	try {
		Thread.sleep(1500);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	flag=true;
	notify();
}
public synchronized void getAnswer(String msg){
	if(!flag){
		try {
			wait();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	System.out.println(Thread.currentThread().getName()+" "+msg);
	try {
		Thread.sleep(1500);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	flag=false;
	notify();
	
}
}
