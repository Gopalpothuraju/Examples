package com.pennant.communication;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Chat chat =new Chat();
		new Sender(chat);
		new Response(chat);
	}

}
