package com.pennant.synchronization;

public class Testing {
	static MyThreadDemo mtd1=new MyThreadDemo(10, 20);
	static MyThreadDemo mtd2=new MyThreadDemo(20, 30);
public static void main(String[] args) {
	//MyThreadDemo mtd=new MyThreadDemo(10, 20);
	Thread t1=new Thread(mtd1,"mythread");
	Thread t2=new Thread(mtd2,"yourthread");
	t1.start();
	t2.start();
}
}
