package com.pennant.annotations;

public class SingleAnnotationClass {
	@SingleValueAnnotation(value=20)
public void userValue(){
	System.out.println("Single value annotation...user value");
}
	
	@SingleValueAnnotation(value = 0)
	public void defaultValue(){

		System.out.println("Single value annotation...default value");
	}
}
