package com.strings;

public class PrintingCountOfSubString {

	public static void main(String[] args) {
		String string1="abbcedf";
		String string2="abbcdef";
		int count=0;
		for (int i = 0; i < string1.length()-1; i++) {
			for (int j = i; j < string2.length()-1;) {
				if(string1.charAt(i)==string2.charAt(j) && (string1.charAt(i+1)==string2.charAt(j+1))){
					count++;
				}
				break;
			}
			
		}
		System.out.println(count);

	}

}
