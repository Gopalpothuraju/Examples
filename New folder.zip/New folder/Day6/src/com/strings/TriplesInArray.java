package com.strings;

import java.util.Scanner;

public class TriplesInArray {
	public static boolean tripleValues(int[] array) {
		boolean flag = false;
		int count = 0;
		for (int i = 0; i < array.length - 1; i++) {
			if (array[i] == array[i + 1] && array[i] == array[i + 2]) {
				count++;
				break;
			}

		}
		if (count != 0) {
			flag = true;
		} else {
			flag = false;
		}
		return flag;
	}

	public static void main(String[] args) {
		int[] array = new int[7];
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter 5 values : ");
		for (int i = 0; i < array.length; i++) {
			array[i] = scanner.nextInt();
		}
		if (tripleValues(array)) {
			System.out.println(false);
		} else {
			System.out.println(true);
		}
		scanner.close();
	}

}
