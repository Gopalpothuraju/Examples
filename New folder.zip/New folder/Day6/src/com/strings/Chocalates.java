package com.strings;

public class Chocalates {
	public static void copiesOfString(String name,int number){
		String subString;
		if(name.length()<3){
			subString=name;
		}else{
			subString=name.substring(0,3);
		}
		for(int i=1;i<=number;i++){
			System.out.print(subString+" ");
		}System.out.println("\n");
	}
	public static void main(String[] args) {
		copiesOfString("chocalate", 2);
		copiesOfString("ab", 3);
	}

}
