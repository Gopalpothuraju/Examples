package com.strings;

public class NumberOfCopies {
	String name;
	int number;
	public static void copiesPrint(String name,int number){
		for(int i=1;i<=number;i++){
			System.out.print(name+" ");
		}System.out.println("\n");
	}
	public static void main(String[] args) {
		copiesPrint("Hi", 2);
		copiesPrint("Hi", 3);
	}

}
