package com.strings;

public class PrintingNumberOfTimes {
	public static void repiting(String string1,int number){
		for (int i = 0; i < number; i++) {
			System.out.print(string1+" ");
		}
		
	}
	public static void main(String[] args) {
		String string1="gopal";
		int number=3;
		repiting(string1, number);
		
	}

}
