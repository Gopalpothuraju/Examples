package com.strings;

public class RotatingList {
	public static int[] rotatingList(int n, int[] list) {
		int[] newList = new int[list.length];
		int index = 0;
		for (int i = 0; i < list.length; i++) {
			if (index == 0) {
				if (list[i] == n) {
					for (int j = i + 1; j < list.length; j++) {
						newList[index] = list[j];
						index++;

					}
					i=0;
				}
			} else if (index < list.length) {
				newList[index] = list[i-1];
				index++;
			} else {
				break;
			}

		}
		return newList;

	}

	public static void main(String[] args) {
		int[] list = { 1, 2, 3, 4, 5, 6 };
		int n = 4;
		list = rotatingList(n, list);
		for (int i = 0; i < list.length; i++) {
			System.out.print(list[i]);
		}
	}
}
